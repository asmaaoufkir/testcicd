install logstash
=========

Pipelines logstash

![schema](docs/schema.drawio.png)
